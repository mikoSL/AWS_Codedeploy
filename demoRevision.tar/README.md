# AWS_Codedeploy (Automated Software Deployment)
* Create a CodeDeploy revision that deploys new code with zero downtime.
* It is the tutorial from A Cloud Guru Ltd. -- "AWS Code Deploy" course by Alex Glover.
